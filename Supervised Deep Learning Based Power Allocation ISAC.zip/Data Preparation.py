import numpy as np
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys

P_TOT_DBM = 30.0
P_TOT_W = 10 ** (P_TOT_DBM / 10) / 1000
NOISE_POWER_DBM = -100.0
NOISE_POWER_W = 10 ** (NOISE_POWER_DBM / 10) / 1000
BANDWIDTH_HZ = 1e6

ANTENNA_GAIN_DBI = 25.0
ANTENNA_GAIN_LIN = 10 ** (ANTENNA_GAIN_DBI / 10)

FC = 28e9
C = 3e8
LAMBDA = C / FC
PATH_LOSS_EXPONENT = 2.5

ALPHA_STEPS = 101
ALPHA_GRID = np.linspace(0, 1, ALPHA_STEPS)

INITIAL_NUM_SAMPLES = 100000
TARGET_NUM_SAMPLES = 20000
NUM_BINS = 20
OUTPUT_FILENAME = 'isac_swerling1_dataset.csv'

def solve_grid_search_batch(h_c_sq_batch, h_r_sq_batch, gamma_sens_batch):
    num_samples = len(h_c_sq_batch)
    alphas = ALPHA_GRID[np.newaxis, :]
    h_c = h_c_sq_batch[:, np.newaxis]
    h_r = h_r_sq_batch[:, np.newaxis]
    gamma_sens = gamma_sens_batch[:, np.newaxis]

    radar_snr = ((1 - alphas) * P_TOT_W * h_r) / NOISE_POWER_W
    valid_mask_sens_snr = radar_snr >= gamma_sens

    comm_snr = (alphas * P_TOT_W * h_c) / NOISE_POWER_W

    valid_mask = valid_mask_sens_snr

    comm_rate = BANDWIDTH_HZ * np.log2(1 + np.maximum(comm_snr, 0))
    comm_rate[~valid_mask] = -1.0

    best_indices = np.argmax(comm_rate, axis=1)
    best_alphas = ALPHA_GRID[best_indices]
    best_alphas = np.where(comm_rate[np.arange(num_samples), best_indices] == -1.0, 0.0, best_alphas)

    return best_alphas

def generate_swerling1_batch(num_samples):
    d_c = np.random.uniform(10, 120, num_samples)
    d_r = d_c

    L0_comm = (LAMBDA / (4 * np.pi)) ** 2
    path_loss_c_base = L0_comm * (d_c ** -PATH_LOSS_EXPONENT)

    L0_radar = (LAMBDA ** 2) / ((4 * np.pi) ** 3)
    path_loss_r_base = L0_radar * (d_r ** -(2 * PATH_LOSS_EXPONENT))

    h_c_fading = np.random.exponential(scale=1.0, size=num_samples)
    h_c_sq = path_loss_c_base * h_c_fading * ANTENNA_GAIN_LIN

    avg_rcs = 1.0
    rcs_inst = np.random.exponential(scale=avg_rcs, size=num_samples)
    h_r_sq = path_loss_r_base * rcs_inst * (ANTENNA_GAIN_LIN ** 2)

    target_gamma_db = np.random.uniform(10, 30, num_samples)
    target_gamma_lin = 10 ** (target_gamma_db / 10)

    max_achievable_snr = (P_TOT_W * h_r_sq) / NOISE_POWER_W
    gamma_th_linear = np.where(target_gamma_lin < max_achievable_snr,
                               target_gamma_lin,
                               max_achievable_snr * 0.99)

    return {
        "dist": d_c, "dist_r": d_r, "rcs_val": rcs_inst,
        "h_c_sq": h_c_sq, "h_r_sq": h_r_sq, "gamma_th_linear": gamma_th_linear,

        "input_h_c_db": 10 * np.log10(np.maximum(h_c_sq, 1e-30)),
        "input_h_r_db": 10 * np.log10(np.maximum(h_r_sq, 1e-30)),
        "input_gamma_db": 10 * np.log10(np.maximum(gamma_th_linear, 1e-30))
    }

if __name__ == "__main__":
    if os.path.exists(OUTPUT_FILENAME):
        print(f"'{OUTPUT_FILENAME}' zaten mevcut. Yeniden oluşturmak için silin.")
        sys.exit(0)

    start_time = time.perf_counter()
    print("--- Veri Üretimi Başlıyor (Akademik Revizyonlu) ---")

    env = generate_swerling1_batch(INITIAL_NUM_SAMPLES)
    alpha_opts = solve_grid_search_batch(env["h_c_sq"], env["h_r_sq"], env["gamma_th_linear"])

    df_raw = pd.DataFrame({
        'input_h_c_db': env["input_h_c_db"],
        'input_h_r_db': env["input_h_r_db"],
        'input_gamma_db': env["input_gamma_db"],
        'meta_dist_comm': env["dist"],
        'meta_dist_radar': env["dist_r"],
        'meta_rcs': env["rcs_val"],
        'output_alpha_opt': alpha_opts
    })

    print(f"Ham veri: {len(df_raw)}")
    df_filtered = df_raw[
        (df_raw['output_alpha_opt'] > 0.1) &
        (df_raw['output_alpha_opt'] < 0.9)
        ].copy()
    print(f"Filtrelenmiş veri: {len(df_filtered)}")

    if len(df_filtered) == 0:
        print("HATA: Kriterlere uygun veri kalmadı. (Anten kazancını artırmayı deneyin)")
        exit()

    print("Dengeleme yapılıyor...")
    bin_edges = np.linspace(0, 1, NUM_BINS + 1)
    bin_edges[-1] += 1e-9
    df_filtered['alpha_bin'] = pd.cut(df_filtered['output_alpha_opt'], bins=bin_edges, labels=range(NUM_BINS),
                                      right=False)

    counts = df_filtered['alpha_bin'].value_counts()
    valid_bins = counts[counts > 0].index
    min_count = counts[valid_bins].min()
    final_count = min(min_count, TARGET_NUM_SAMPLES // len(valid_bins))

    df_sampled_list = []
    for bin_label in valid_bins:
        bin_data = df_filtered[df_filtered['alpha_bin'] == bin_label]
        df_sampled_list.append(bin_data.sample(n=final_count, random_state=42))

    if df_sampled_list:
        df_train = pd.concat(df_sampled_list).sample(frac=1, random_state=42).reset_index(drop=True)
        df_train = df_train.drop(columns=['alpha_bin'])
        df_train.to_csv(OUTPUT_FILENAME, index=False)
        end_time = time.perf_counter()
        print(f"[BAŞARILI] '{OUTPUT_FILENAME}' kaydedildi. Boyut: {len(df_train)}")
        print(f"Toplam Oluşturma Süresi: {end_time - start_time:.2f} saniye")

        sns.set_theme(style="whitegrid")

        fig1 = plt.figure(1, figsize=(10, 7))
        ax1 = fig1.add_subplot(111)

        sns.histplot(df_train['output_alpha_opt'], bins=20, kde=False, ax=ax1, color='purple')
        ax1.set_title('1. Optimal Alpha Distribution (Balanced)')
        ax1.set_xlabel('Alpha')
        ax1.set_ylabel('Number of Samples')
        ax1.set_xlim(0, 1)

        plt.tight_layout()
        plt.savefig('figure1_alpha_distribution.png')
        print("Figure 1 saved as 'figure1_alpha_distribution.png'.")

        h_r_lin = 10 ** (df_train['input_h_r_db'] / 10)
        gamma_lin = 10 ** (df_train['input_gamma_db'] / 10)

        max_achievable_snr = (P_TOT_W * h_r_lin) / NOISE_POWER_W
        load_ratio = gamma_lin / (max_achievable_snr + 1e-9)
        load_ratio = np.clip(load_ratio, 0, 1.05)

        fig2 = plt.figure(2, figsize=(10, 7))
        ax2 = fig2.add_subplot(111)

        hb = ax2.hexbin(load_ratio, df_train['output_alpha_opt'], gridsize=40, cmap='inferno', mincnt=1)

        x_ref = np.linspace(0, 1, 100)
        ax2.plot(x_ref, 1 - x_ref, 'c--', linewidth=2, label='Theoretical Limit (1 - Difficulty)')

        cbar = fig2.colorbar(hb, ax=ax2)
        cbar.set_label('Sample Density')

        ax2.set_title('2. Proof of Perfect Efficiency (Difficulty vs Alpha)', fontsize=14)
        ax2.set_xlabel('Difficulty Level (Target Constraint / Channel Capacity)', fontsize=12)
        ax2.set_ylabel('Optimal Communication Share ($\\alpha$)', fontsize=12)
        ax2.set_xlim(0, 1)
        ax2.set_ylim(0, 1)
        ax2.legend()

        plt.tight_layout()
        plt.savefig('figure2_difficulty_vs_alpha.png')
        print("Figure 2 saved as 'figure2_difficulty_vs_alpha.png'.")

        sample_df = df_train.sample(min(500, len(df_train)))

        fig3 = plt.figure(3, figsize=(10, 7))
        ax3 = fig3.add_subplot(111)

        ax3.scatter(
            sample_df['meta_dist_comm'], sample_df['input_h_c_db'],
            label='Communication ($R^{2.5}$ Rayleigh)', alpha=0.6,
            color='blue', s=15
        )
        ax3.scatter(
            sample_df['meta_dist_radar'], sample_df['input_h_r_db'],
            label='Radar ($R^{5.0}$ Swerling 1)', alpha=0.6,
            color='red', s=15
        )

        ax3.set_title('3. Physical Channel Model Sanity Check')
        ax3.set_xlabel('Distance (m)')
        ax3.set_ylabel('Channel Power (dB)')
        ax3.legend()
        ax3.grid(True, linestyle='--', alpha=0.5)

        plt.tight_layout()
        plt.savefig('figure3_channel_power_comparison.png')
        print("Figure 3 saved as 'figure3_channel_power_comparison.png'.")

        bins_d = np.linspace(df_filtered['meta_dist_radar'].min(), df_filtered['meta_dist_radar'].max(), 20)
        df_filtered['dist_bin'] = pd.cut(df_filtered['meta_dist_radar'], bins_d, include_lowest=True)

        agg_df = df_filtered.groupby('dist_bin', observed=True).agg(
            mean_alpha=('output_alpha_opt', 'mean'),
            count=('output_alpha_opt', 'size')
        ).reset_index()

        MIN_SAMPLES_PER_BIN = 20
        agg_df_valid = agg_df[agg_df['count'] >= MIN_SAMPLES_PER_BIN]
        centers = [i.mid for i in agg_df_valid['dist_bin']]

        fig4 = plt.figure(4, figsize=(10, 7))
        ax4 = fig4.add_subplot(111)

        ax4.scatter(df_filtered['meta_dist_radar'], df_filtered['output_alpha_opt'], s=5, alpha=0.05, color='gray')
        ax4.plot(centers, agg_df_valid['mean_alpha'], 'r-o', linewidth=3, label='Reliable Mean Trend')

        ax4.set_title('4. Radar Distance vs Alpha Trend (Filtered)')
        ax4.set_xlabel('Radar Distance (m)')
        ax4.set_ylabel('Alpha')
        ax4.set_ylim(0, 1)
        ax4.legend()

        plt.tight_layout()
        plt.savefig('figure4_radar_distance_alpha_trend.png')
        print("Figure 4 saved as 'figure4_radar_distance_alpha_trend.png'.")