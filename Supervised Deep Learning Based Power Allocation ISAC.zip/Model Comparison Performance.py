import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import joblib
import os
import tensorflow as tf

SCALER_FILE = 'isac_scaler.pkl'
TEST_CSV_FILENAME_SPLIT = 'isac_test_data_split.csv'

TFLITE_MODELS = [
    ("Baseline MLP", "isac_dnn_model_M1.tflite"),
    ("Dropout MLP",  "isac_dnn_model_M2.tflite"),
    ("Residual MLP", "isac_dnn_model_M3.tflite"),
    ("CNN (1D)",     "isac_dnn_model_M4.tflite"),
    ("Weak MLP",     "isac_dnn_model_M5.tflite"),
]

ALPHA_STEPS = 101
ALPHA_GRID = np.linspace(0.0, 1.0, ALPHA_STEPS)
BANDWIDTH_HZ = 1e6
NUM_TEST_SAMPLES = 200

INPUT_FEATURES = ['input_h_c_db', 'input_h_r_db', 'input_gamma_db']
OUTPUT_TARGET = 'output_alpha_opt'

P_TOT_DBM = 30.0
P_TOT_W = 10 ** (P_TOT_DBM / 10) / 1000
NOISE_POWER_DBM = -100.0
NOISE_POWER_W = 10 ** (NOISE_POWER_DBM / 10) / 1000

def solve_with_grid_search_and_time(row):
    h_c_sq = 10 ** (row['input_h_c_db'] / 10.0)
    h_r_sq = 10 ** (row['input_h_r_db'] / 10.0)
    gamma_lin = 10 ** (row['input_gamma_db'] / 10.0)

    max_rate = -1.0
    start_time = time.perf_counter()

    for alpha in ALPHA_GRID:
        p_sens = (1 - alpha) * P_TOT_W
        sinr_radar = (p_sens * h_r_sq) / NOISE_POWER_W

        if sinr_radar >= gamma_lin:
            p_comm = alpha * P_TOT_W
            snr_comm = (p_comm * h_c_sq) / NOISE_POWER_W
            rate = BANDWIDTH_HZ * np.log2(1 + max(snr_comm, 0))
            if rate > max_rate:
                max_rate = rate

    return (time.perf_counter() - start_time) * 1000.0

def load_tflite_interpreter(model_path):
    interpreter = tf.lite.Interpreter(model_path=model_path)
    interpreter.allocate_tensors()
    input_index = interpreter.get_input_details()[0]['index']
    output_index = interpreter.get_output_details()[0]['index']
    return interpreter, input_index, output_index

def _safe_get_ops_details(interpreter):
    if hasattr(interpreter, "_get_ops_details"):
        return interpreter._get_ops_details()
    return []

def extract_arch_from_tflite(model_path):
    interpreter = tf.lite.Interpreter(model_path=model_path)
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    tensor_details = interpreter.get_tensor_details()
    ops = _safe_get_ops_details(interpreter)

    in_shape = input_details[0]["shape"]
    input_dim = int(in_shape[-1]) if len(in_shape) >= 2 else int(np.prod(in_shape))

    dense_units = []
    conv_blocks = []

    for op in ops:
        op_name = op.get("op_name", "")

        if op_name == "FULLY_CONNECTED":
            inp_ids = op.get("inputs", [])
            if len(inp_ids) >= 2:
                w_id = inp_ids[1]
                w_info = next((t for t in tensor_details if t["index"] == w_id), None)
                if w_info is not None:
                    w_shape = w_info.get("shape", None)
                    if w_shape is not None and len(w_shape) == 2:
                        out_units = int(w_shape[0])
                        dense_units.append(out_units)

        if op_name == "CONV_2D":
            inp_ids = op.get("inputs", [])
            if len(inp_ids) >= 2:
                w_id = inp_ids[1]
                w_info = next((t for t in tensor_details if t["index"] == w_id), None)
                if w_info is not None:
                    w_shape = w_info.get("shape", None)
                    if w_shape is not None and len(w_shape) == 4:
                        filters_a = int(w_shape[0])
                        filters_b = int(w_shape[-1])
                        filters = filters_a if filters_a >= filters_b else filters_b

                        kh1, kw1 = int(w_shape[1]), int(w_shape[2])
                        kh2, kw2 = int(w_shape[0]), int(w_shape[1])
                        if 1 <= kh1 <= 15 and 1 <= kw1 <= 15:
                            kernel_str = f"{kh1}x{kw1}"
                        else:
                            kernel_str = f"{kh2}x{kw2}"

                        conv_blocks.append((filters, kernel_str))

    out_shape = output_details[0]["shape"]
    output_dim = int(out_shape[-1]) if len(out_shape) >= 2 else int(np.prod(out_shape))

    cleaned_dense = []
    for u in dense_units:
        if len(cleaned_dense) == 0 or cleaned_dense[-1] != u:
            cleaned_dense.append(u)

    return {
        "input_dim": input_dim,
        "dense_units": cleaned_dense,
        "conv_blocks": conv_blocks,
        "output_dim": output_dim
    }

def draw_neurons_diagram(model_title, arch, out_png):
    input_dim = arch["input_dim"]
    output_dim = arch["output_dim"]
    dense_units = arch["dense_units"]
    conv_blocks = arch["conv_blocks"]

    stages = [("Input", f"{input_dim}")]
    for i, (filt, kstr) in enumerate(conv_blocks, start=1):
        stages.append((f"Conv{i}", f"{filt} filters\n(k={kstr})"))
    for i, u in enumerate(dense_units, start=1):
        stages.append((f"Dense{i}", f"{u}"))
    stages.append(("Output", f"{output_dim}"))

    n = len(stages)

    fig = plt.figure(figsize=(1.9 * n + 2, 4.8))
    ax = fig.add_subplot(111)
    ax.set_title(model_title, fontsize=13)
    ax.axis("off")

    xs = np.linspace(0.08, 0.92, n)
    y = 0.55

    for i, (name, val) in enumerate(stages):
        x = xs[i]
        w, h = 0.12, 0.22
        rect = plt.Rectangle((x - w / 2, y - h / 2), w, h, fill=False, linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y + 0.05, name, ha="center", va="center", fontsize=10)
        ax.text(x, y - 0.06, val, ha="center", va="center", fontsize=10)

        if i < n - 1:
            ax.annotate(
                "",
                xy=(xs[i + 1] - w / 2, y),
                xytext=(x + w / 2, y),
                arrowprops=dict(arrowstyle="->", linewidth=2)
            )

    plt.tight_layout()
    plt.savefig(out_png, dpi=220)
    plt.close(fig)

def _display_neuron_slots(n, max_show=20):
    n = int(n)
    if n <= max_show:
        return list(range(n))
    head = list(range(8))
    tail = list(range(n - 8, n))
    return head + [None] + tail

def draw_mlp_neuron_schema(layer_sizes, title, out_png, max_show_per_layer=20):
    layer_sizes = [int(x) for x in layer_sizes]
    L = len(layer_sizes)

    fig_w = max(10, 2.2 * L)
    fig_h = 6.5
    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_subplot(111)
    ax.set_title(title, fontsize=14)
    ax.axis("off")

    xs = np.linspace(0.08, 0.92, L)

    layer_points = []
    for li, n in enumerate(layer_sizes):
        slots = _display_neuron_slots(n, max_show=max_show_per_layer)

        m = len(slots)
        if m == 1:
            ys = np.array([0.5])
        elif m == 2:
            ys = np.array([0.62, 0.38])
        else:
            ys = np.linspace(0.85, 0.15, m)

        layer_points.append((xs[li], slots, ys))

    for li in range(L - 1):
        x1, slots1, ys1 = layer_points[li]
        x2, slots2, ys2 = layer_points[li + 1]

        idx1 = [k for k, s in enumerate(slots1) if s is not None]
        idx2 = [k for k, s in enumerate(slots2) if s is not None]

        for i in idx1:
            for j in idx2:
                ax.plot([x1, x2], [ys1[i], ys2[j]], linewidth=0.6, alpha=0.25)

    for li, n in enumerate(layer_sizes):
        x, slots, ys = layer_points[li]

        if li == 0:
            layer_name = f"Input\n({n})"
        elif li == L - 1:
            layer_name = f"Output\n({n})"
        else:
            layer_name = f"Hidden {li}\n({n})"

        ax.text(x, 0.05, layer_name, ha="center", va="center", fontsize=11)

        for k, s in enumerate(slots):
            if s is None:
                ax.text(x, ys[k], "...", ha="center", va="center", fontsize=14)
            else:
                circ = plt.Circle((x, ys[k]), 0.012, fill=False, linewidth=1.5)
                ax.add_patch(circ)

    plt.tight_layout()
    plt.savefig(out_png, dpi=250)
    plt.close(fig)

if __name__ == "__main__":
    missing = []
    for f in [SCALER_FILE, TEST_CSV_FILENAME_SPLIT]:
        if not os.path.exists(f):
            missing.append(f)
    for _, p in TFLITE_MODELS:
        if not os.path.exists(p):
            missing.append(p)
    if missing:
        print("HATA: Eksik dosyalar:")
        for m in missing:
            print(" -", m)
        raise SystemExit(1)

    scaler = joblib.load(SCALER_FILE)
    df_full = pd.read_csv(TEST_CSV_FILENAME_SPLIT)
    df_test = df_full.sample(n=min(NUM_TEST_SAMPLES, len(df_full)), random_state=42).reset_index(drop=True)

    actual_alphas = df_test[OUTPUT_TARGET].values.astype(np.float32)
    raw_inputs = df_test[INPUT_FEATURES].values
    scaled_inputs = scaler.transform(raw_inputs).astype(np.float32)

    gs_times = [solve_with_grid_search_and_time(row) for _, row in df_test.iterrows()]
    avg_gs_time = float(np.mean(gs_times))

    model_names, avg_tflite_times, maes = [], [], []
    preds_by_model, abs_err_by_model = {}, {}

    for name, path in TFLITE_MODELS:
        interpreter, input_index, output_index = load_tflite_interpreter(path)

        t_times, preds = [], []
        for i in range(len(df_test)):
            x = scaled_inputs[i].reshape(1, -1)
            start = time.perf_counter()
            interpreter.set_tensor(input_index, x)
            interpreter.invoke()
            y_pred = interpreter.get_tensor(output_index)[0][0]
            t_times.append((time.perf_counter() - start) * 1000.0)
            preds.append(y_pred)

        preds = np.array(preds, dtype=np.float32)
        mae = float(np.mean(np.abs(actual_alphas - preds)))

        model_names.append(name)
        avg_tflite_times.append(float(np.mean(t_times)))
        maes.append(mae)
        preds_by_model[name] = preds
        abs_err_by_model[name] = np.abs(actual_alphas - preds)

        print(f"{name:12s} | MAE={mae:.6f} | Time={np.mean(t_times):.4f} ms")

    plt.figure(figsize=(10, 7))
    ax1 = plt.gca()
    speed_labels = ["Grid Search"] + model_names
    speed_values = [avg_gs_time] + avg_tflite_times
    bars = ax1.bar(speed_labels, speed_values)
    ax1.set_ylabel("ms")
    ax1.set_title("Inference Time (Avg)")
    ax1.tick_params(axis='x', rotation=20)
    for b in bars:
        ax1.text(b.get_x() + b.get_width() / 2, b.get_height(), f"{b.get_height():.4f}",
                 ha="center", va="bottom")
    plt.tight_layout()
    out_file1 = "performance1.png"
    plt.savefig(out_file1, dpi=200)
    plt.close()
    print(f"\n✅ Grafik kaydedildi: {out_file1}")

    fig = plt.figure(figsize=(22, 7))

    ax2 = plt.subplot(1, 3, 1)
    bars2 = ax2.bar(model_names, maes)
    ax2.set_ylabel("MAE")
    ax2.set_title("Performance 2: Accuracy (MAE)")
    ax2.tick_params(axis='x', rotation=20)
    for b in bars2:
        ax2.text(b.get_x() + b.get_width() / 2, b.get_height(), f"{b.get_height():.5f}",
                 ha="center", va="bottom")

    ax3 = plt.subplot(1, 3, 2)
    for n in model_names:
        ax3.scatter(actual_alphas, preds_by_model[n], s=12, alpha=0.35, label=n)
    ax3.plot([0, 1], [0, 1], linestyle="--")
    ax3.set_xlim(0, 1)
    ax3.set_ylim(0, 1)
    ax3.set_xlabel("True Alpha")
    ax3.set_ylabel("Predicted Alpha")
    ax3.set_title("Performance 3: True vs Predicted")
    ax3.legend(fontsize=8)

    ax4 = plt.subplot(1, 3, 3)
    for n in model_names:
        ax4.hist(abs_err_by_model[n], bins=30, alpha=0.45, label=n)
    ax4.set_xlabel("|Error|")
    ax4.set_ylabel("Count")
    ax4.set_title("Performance 4: Error Distribution")
    ax4.legend(fontsize=8)

    plt.tight_layout()
    out_file234 = "performance234.png"
    plt.savefig(out_file234, dpi=200)
    plt.close(fig)
    print(f"✅ Grafik kaydedildi: {out_file234}")

    for idx, (name, path) in enumerate(TFLITE_MODELS, start=1):
        arch = extract_arch_from_tflite(path)
        out_png = f"model{idx}_neurons.png"
        draw_neurons_diagram(f"Model {idx}: {name} (TFLite)", arch, out_png)
        print(f"✅ Saved: {out_png}")

    base_arch = extract_arch_from_tflite(TFLITE_MODELS[0][1])
    layer_sizes = [base_arch["input_dim"]] + base_arch["dense_units"] + [base_arch["output_dim"]]

    draw_mlp_neuron_schema(
        layer_sizes=layer_sizes,
        title=f"General Deep Learning Model Schema",
        out_png="dl_schema_overview.png",
        max_show_per_layer=20
    )
    print("✅ Saved: dl_schema_overview.png")