import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
import joblib

TFLITE_MODEL_FILE = 'isac_dnn_model.tflite'
SCALER_FILE = 'isac_scaler.pkl'

P_TOT_DBM = 30.0
P_TOT_W = 10 ** (P_TOT_DBM / 10) / 1000
NOISE_POWER_DBM = -100.0
NOISE_POWER_W = 10 ** (NOISE_POWER_DBM / 10) / 1000
ANTENNA_GAIN_LIN = 10 ** (25.0 / 10)
FC = 28e9
C = 3e8
LAMBDA = C / FC
PATH_LOSS_EXPONENT = 2.5

interpreter = tf.lite.Interpreter(model_path=TFLITE_MODEL_FILE)
interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
scaler = joblib.load(SCALER_FILE)

print("Scenario Simulation: Target moves from 10m to 150m...")

distances = np.linspace(10, 100, 100)
alphas = []
radar_snrs_db = []

TARGET_GAMMA_DB = 20
TARGET_GAMMA_LIN = 10 ** (TARGET_GAMMA_DB / 10)

k = 6.0

for d in distances:
    path_loss_c = (LAMBDA / (4 * np.pi)) ** 2 * (d ** -PATH_LOSS_EXPONENT)
    path_loss_r = (LAMBDA ** 2) / ((4 * np.pi) ** 3) * (d ** -(2 * PATH_LOSS_EXPONENT))

    h_c_sq = path_loss_c * 1.0 * ANTENNA_GAIN_LIN
    h_r_sq = path_loss_r * 1.0 * (ANTENNA_GAIN_LIN ** 2)

    input_vec = np.array([[
        10 * np.log10(h_c_sq),
        10 * np.log10(h_r_sq),
        TARGET_GAMMA_DB
    ]])

    input_scaled = scaler.transform(input_vec).astype(np.float32)
    interpreter.set_tensor(input_details[0]['index'], input_scaled)
    interpreter.invoke()

    raw = float(interpreter.get_tensor(output_details[0]['index'])[0][0])

    alpha = 0.1 + 0.8 * (1.0 / (1.0 + np.exp(-k * (raw - 0.5))))
    alphas.append(alpha)

    radar_p = (1.0 - alpha) * P_TOT_W
    radar_sinr = (radar_p * h_r_sq) / NOISE_POWER_W
    radar_snrs_db.append(10.0 * np.log10(radar_sinr))

fig, ax1 = plt.subplots(figsize=(11, 6))

ax1.set_xlabel("Distance (m)", fontsize=13)
ax1.set_ylabel("Communication Power Fraction (α)", fontsize=13)
ax1.plot(distances, alphas, linewidth=3.5, label="α (DNN output, soft-clipped to [0.1, 0.9])")
ax1.set_ylim(0, 1.05)
ax1.grid(True, alpha=0.3)

ax2 = ax1.twinx()
ax2.set_ylabel("Radar SINR (dB)", fontsize=13)
ax2.plot(
    distances, radar_snrs_db,
    color="red", linestyle="--", linewidth=3,
    label="Radar SINR (resulting)"
)
ax2.axhline(
    y=TARGET_GAMMA_DB,
    color="green", linestyle=":", linewidth=2.5,
    label=f"Radar SINR constraint (γ = {TARGET_GAMMA_DB} dB)"
)

plt.title("Live Scenario: Dynamic Power Allocation for a Receding Target", fontsize=15)

h1, l1 = ax1.get_legend_handles_labels()
h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1 + h2, l1 + l2, fontsize=9, loc="upper right")

fig.tight_layout()
plt.savefig("scenario_simulation.png", dpi=200)
print("✅ Saved: scenario_simulation.png")