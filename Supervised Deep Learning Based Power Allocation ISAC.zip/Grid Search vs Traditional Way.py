import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys

INPUT_CSV_FILENAME = 'isac_swerling1_dataset.csv'
COMPARISON_FILENAME = 'alpha_validation_comparison.csv'
PLOT_FILENAME = 'closed_vs_dataset_validation.png'

P_TOT_DBM = 30.0
P_TOT_W = 10 ** (P_TOT_DBM / 10) / 1000
NOISE_POWER_DBM = -100.0
NOISE_POWER_W = 10 ** (NOISE_POWER_DBM / 10) / 1000

ALPHA_STEPS = 1001
ALPHA_GRID = np.linspace(0.0, 1.0, ALPHA_STEPS)

def closed_form_alpha_from_row(row):
    h_r_sq = 10 ** (row['input_h_r_db'] / 10.0)
    gamma_lin = 10 ** (row['input_gamma_db'] / 10.0)

    load_ratio = (gamma_lin * NOISE_POWER_W) / (P_TOT_W * h_r_sq + 1e-30)
    alpha_opt_calc = 1.0 - load_ratio

    return float(np.clip(alpha_opt_calc, 0.0, 1.0))

if __name__ == "__main__":
    if not os.path.exists(INPUT_CSV_FILENAME):
        print(f"ERROR: Data file '{INPUT_CSV_FILENAME}' not found.")
        sys.exit(1)

    df = pd.read_csv(INPUT_CSV_FILENAME)

    df['alpha_opt_closed'] = df.apply(closed_form_alpha_from_row, axis=1)

    mse = mean_squared_error(df['output_alpha_opt'], df['alpha_opt_closed'])
    rmse = np.sqrt(mse)

    print("-" * 60)
    print("VALIDATION RESULT (Dataset Alpha vs. Closed Form)")
    print(f"Total samples: {len(df)}")
    print(f"RMSE (Dataset vs. Closed Form): {rmse:.8e}")
    print("Note: RMSE is non-zero due to the discretization of Grid Search.")
    print("-" * 60)

    sns.set_theme(style="whitegrid")
    plt.figure(figsize=(8, 8))

    plt.scatter(df['alpha_opt_closed'], df['output_alpha_opt'],
                s=15, alpha=0.5, label='Alpha Samples', color='darkblue')

    plt.plot([0, 1], [0, 1], 'r--', linewidth=2, label='Ideal Match (y=x)')

    plt.title('Validation of Alpha Solutions (Closed Form vs. Grid Search)', fontsize=14)
    plt.xlabel('Closed Form Alpha', fontsize=12)
    plt.ylabel('Dataset Alpha (Grid Search)', fontsize=12)
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.legend(loc='upper left')
    plt.grid(True, linestyle='--', alpha=0.7)

    plt.savefig(PLOT_FILENAME)
    print(f"Validation plot saved as '{PLOT_FILENAME}'.")

    df_output = df[['output_alpha_opt', 'alpha_opt_closed']]
    df_output.to_csv(COMPARISON_FILENAME, index=False)
    print(f"Comparison file saved as '{COMPARISON_FILENAME}' (2 columns only).")