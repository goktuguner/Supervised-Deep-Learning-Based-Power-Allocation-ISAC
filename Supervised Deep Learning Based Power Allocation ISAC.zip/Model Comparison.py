import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib
import os
import sys

from tensorflow.keras import Model
from tensorflow.keras.layers import Input, BatchNormalization, Add, Activation
from tensorflow.keras.layers import Reshape, Conv1D, GlobalAveragePooling1D

INPUT_CSV_FILENAME = 'isac_swerling1_dataset.csv'
TEST_CSV_FILENAME = 'isac_test_data_split.csv'
SCALER_FILE = 'isac_scaler.pkl'

EPOCHS = 300
BATCH_SIZE = 64
PATIENCE = 30
VALIDATION_SPLIT = 0.2
TEST_SIZE = 0.2

INPUT_FEATURES = ['input_h_c_db', 'input_h_r_db', 'input_gamma_db']
OUTPUT_TARGET = 'output_alpha_opt'

BEST_MODEL_TFLITE = 'isac_dnn_model.tflite'
BEST_MODEL_KERAS = 'isac_dnn_model_best.keras'

if not os.path.exists(INPUT_CSV_FILENAME):
    print(f"HATA: Veri dosyası '{INPUT_CSV_FILENAME}' bulunamadı.")
    sys.exit(1)

df = pd.read_csv(INPUT_CSV_FILENAME)
X = df[INPUT_FEATURES].values
y = df[OUTPUT_TARGET].values

X_train_raw, X_test_raw, y_train, y_test = train_test_split(
    X, y, test_size=TEST_SIZE, random_state=42
)

df_test_out = pd.DataFrame(X_test_raw, columns=INPUT_FEATURES)
df_test_out[OUTPUT_TARGET] = y_test
df_test_out.to_csv(TEST_CSV_FILENAME, index=False)
print(f"-> Test Verisi '{TEST_CSV_FILENAME}' kaydedildi ({len(df_test_out)} örnek).")

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_raw)
X_test_scaled = scaler.transform(X_test_raw)
joblib.dump(scaler, SCALER_FILE)
print(f"-> Scaler '{SCALER_FILE}' kaydedildi.")

def create_model(model_name, model_type="mlp", layer_sizes=None, dropout_rate=0.0):
    input_dim = len(INPUT_FEATURES)

    if model_type != "cnn1d":
        layer_sizes = layer_sizes or [128, 128, 64, 32]

    if model_type == "mlp":
        m = Sequential(name=model_name)
        m.add(Dense(layer_sizes[0], activation='relu', input_shape=(input_dim,)))
        for s in layer_sizes[1:]:
            m.add(Dense(s, activation='relu'))
        m.add(Dense(1, activation='sigmoid'))
        m.compile(optimizer='adam', loss='mse', metrics=['mae', 'mse'])
        return m

    if model_type == "dropout":
        m = Sequential(name=model_name)
        m.add(Dense(layer_sizes[0], activation='relu', input_shape=(input_dim,)))
        for s in layer_sizes[1:]:
            m.add(Dense(s, activation='relu'))
            if dropout_rate > 0.0:
                m.add(Dropout(dropout_rate))
        m.add(Dense(1, activation='sigmoid'))
        m.compile(optimizer='adam', loss='mse', metrics=['mae', 'mse'])
        return m

    if model_type == "residual":
        inp = Input(shape=(input_dim,), name="input")
        x = inp
        for i, s in enumerate(layer_sizes):
            shortcut = x
            x = Dense(s, use_bias=False, name=f"res_dense_{i}")(x)
            x = BatchNormalization(name=f"res_bn_{i}")(x)
            x = Activation("relu", name=f"res_relu_{i}")(x)

            if shortcut.shape[-1] != x.shape[-1]:
                shortcut = Dense(s, use_bias=False, name=f"res_proj_{i}")(shortcut)

            x = Add(name=f"res_add_{i}")([x, shortcut])
            x = Activation("relu", name=f"res_out_relu_{i}")(x)

        out = Dense(1, activation="sigmoid", name="output")(x)
        m = Model(inp, out, name=model_name)
        m.compile(optimizer='adam', loss='mse', metrics=['mae', 'mse'])
        return m

    if model_type == "cnn1d":
        inp = Input(shape=(input_dim,), name="input")
        x = Reshape((input_dim, 1), name="reshape")(inp)

        x = Conv1D(32, kernel_size=2, padding="same", activation="relu", name="conv1")(x)
        x = Conv1D(64, kernel_size=2, padding="same", activation="relu", name="conv2")(x)

        x = GlobalAveragePooling1D(name="gap")(x)
        x = Dense(64, activation="relu", name="head_dense")(x)
        if dropout_rate > 0.0:
            x = Dropout(dropout_rate, name="head_dropout")(x)

        out = Dense(1, activation="sigmoid", name="output")(x)
        m = Model(inp, out, name=model_name)
        m.compile(optimizer='adam', loss='mse', metrics=['mae', 'mse'])
        return m

    raise ValueError(f"Unknown model_type: {model_type}")

model_configs = [
    {
        "name": "baseline_mlp",
        "display_name": "Baseline MLP",
        "model_type": "mlp",
        "layers": [128, 128, 64, 32],
        "dropout": 0.0,
        "save_name": "isac_dnn_model_M1.keras",
        "tflite_name": "isac_dnn_model_M1.tflite",
    },
    {
        "name": "dropout_mlp",
        "display_name": "Dropout MLP",
        "model_type": "dropout",
        "layers": [128, 128, 64, 32],
        "dropout": 0.2,
        "save_name": "isac_dnn_model_M2.keras",
        "tflite_name": "isac_dnn_model_M2.tflite",
    },
    {
        "name": "residual_mlp",
        "display_name": "Residual MLP",
        "model_type": "residual",
        "layers": [128, 128, 64, 32],
        "dropout": 0.0,
        "save_name": "isac_dnn_model_M3.keras",
        "tflite_name": "isac_dnn_model_M3.tflite",
    },
    {
        "name": "cnn1d",
        "display_name": "CNN (1D)",
        "model_type": "cnn1d",
        "layers": None,
        "dropout": 0.1,
        "save_name": "isac_dnn_model_M4.keras",
        "tflite_name": "isac_dnn_model_M4.tflite",
    },
    {
        "name": "weak_mlp",
        "display_name": "Weak MLP",
        "model_type": "dropout",
        "layers": [8, 4],
        "dropout": 0.5,
        "epochs": 80,
        "patience": 8,
        "save_name": "isac_dnn_model_M5.keras",
        "tflite_name": "isac_dnn_model_M5.tflite",
    },
]

results = []
best_mae = float("inf")
best_config = None

for cfg in model_configs:
    print("\n" + "=" * 60)
    print(f"TRAINING: {cfg['display_name']}")
    print("=" * 60)

    model = create_model(
        model_name=cfg["name"],
        model_type=cfg["model_type"],
        layer_sizes=cfg.get("layers"),
        dropout_rate=cfg.get("dropout", 0.0),
    )

    epochs = cfg.get("epochs", EPOCHS)
    patience = cfg.get("patience", PATIENCE)

    early_stopping = EarlyStopping(monitor="val_loss", patience=patience, restore_best_weights=True)
    checkpoint = ModelCheckpoint(cfg["save_name"], monitor="val_loss", save_best_only=True)

    model.fit(
        X_train_scaled, y_train,
        epochs=epochs,
        batch_size=BATCH_SIZE,
        validation_split=VALIDATION_SPLIT,
        callbacks=[early_stopping, checkpoint],
        verbose=2
    )

    loaded = tf.keras.models.load_model(cfg["save_name"], compile=False)
    loaded.compile(optimizer="adam", loss="mse", metrics=["mae", "mse"])

    loss, mae, mse = loaded.evaluate(X_test_scaled, y_test, verbose=0)

    converter = tf.lite.TFLiteConverter.from_keras_model(loaded)
    tflite_model = converter.convert()
    with open(cfg["tflite_name"], "wb") as f:
        f.write(tflite_model)

    print(f"-> Saved: {cfg['tflite_name']}")
    print(f"-> TEST MAE: {mae:.8f} | TEST MSE: {mse:.8f} | Params: {loaded.count_params()}")

    results.append({
        "Model": cfg["display_name"],
        "Type": cfg["model_type"],
        "Test_MAE": float(mae),
        "Test_MSE": float(mse),
        "Params": int(loaded.count_params()),
        "Keras": cfg["save_name"],
        "TFLite": cfg["tflite_name"],
    })

    if mae < best_mae:
        best_mae = mae
        best_config = cfg

df_results = pd.DataFrame(results).sort_values(by="Test_MAE", ascending=True)
print("\n" + "#" * 80)
print("MODEL KARŞILAŞTIRMA SONUÇLARI")
print("#" * 80)
print(df_results.to_string(index=False, float_format="%.8f"))
print("#" * 80)

if best_config is None:
    print("HATA: En iyi model seçilemedi.")
    sys.exit(1)

print("\n" + "=" * 60)
print(f"BEST MODEL: {best_config['display_name']} | MAE: {best_mae:.8f}")
print("=" * 60)

best_model = tf.keras.models.load_model(best_config["save_name"], compile=False)
best_model.compile(optimizer="adam", loss="mse", metrics=["mae", "mse"])
best_model.save(BEST_MODEL_KERAS)

best_converter = tf.lite.TFLiteConverter.from_keras_model(best_model)
best_tflite = best_converter.convert()
with open(BEST_MODEL_TFLITE, "wb") as f:
    f.write(best_tflite)

print(f"-> Saved best Keras: {BEST_MODEL_KERAS}")
print(f"-> Saved best TFLite: {BEST_MODEL_TFLITE}")